import com.files.Files;
import com.java.car_rental.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.*;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import static com.files.Files.*;


public class Main{
    private static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args){
        Files.Read("C:/Users/aseel/IdeaProjects/Main/car.txt");
        // Customer c =new Customer();
        Admin a= new Admin();

        while (true) {
            System.out.println("1) Register as new customer\n2) Login\n3) Logout\n4) Exit \nChoose option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
              //  c.registration();
                    break;
                case 2:
                System.out.println("Login as Admin or Customer?");
                    String registerOption= scanner.next();
                    if(registerOption.equalsIgnoreCase("Admin")){
                        Admin.loginUser();
                    }
                    else if (registerOption.equalsIgnoreCase("Customer")) {
                //        Customer.loginUser();
                    }
                    else{
                        System.out.println("_________________________________");
                        System.out.println("Invalid answer. Please try again.");
                        System.out.println("_________________________________");
                    }
                    break;
                case 3:
           //         Customer.logoutUser();
                    break;
                case 4:
                    System.out.println("Exiting program. User data saved.");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}