package com.files;
import com.java.car_rental.*;

import java.io.*;
import java.util.ArrayList;
import static com.java.car_rental.Admin.vehicles;

public interface Files {
    public static void Read(String path) {
        try {
            FileReader read = new FileReader(path);
            BufferedReader reader = new BufferedReader(read);
            String line;
            while (((line = reader.readLine()) != null)) {
                // Process each line and create a vehicle object
                String[] values = line.split(","); // Assuming comma-separated values
                if (path.equals("C:/Users/aseel/IdeaProjects/Main/car.txt")) {
                    vehicles.add(new Car(Integer.parseInt(values[0]), values[1], values[2], values[3], Integer.parseInt(values[4]), values[5], Double.parseDouble(values[6]), Double.parseDouble(values[7]), values[8]));
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
    public static void Write(String path) {
        try {
            FileWriter writer = new FileWriter(path, false);
            for (Vehicle v : vehicles) {
                writer.write(v.displayInfo());
            }
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}