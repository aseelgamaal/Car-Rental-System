package com.java.car_rental;
import com.files.Files;
import com.files.Files;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

import static java.nio.file.Files.delete;

public class Admin implements Files{
    public static ArrayList<Car> vehicles = new ArrayList<Car>();
    static Scanner scanner = new Scanner(System.in);

    public static void addCar() {
        boolean rented = true;
        boolean more = true;
        do {
            System.out.println("Enter car ID: ");
            int vehicleID = scanner.nextInt();
            System.out.println("Enter car make: ");
            String make = scanner.next();
            System.out.println("Enter car model: ");
            String model = scanner.next();
            System.out.println("Enter car color: ");
            String color = scanner.next();
            System.out.println("Enter car year of manufacture: ");
            int yearOfMan = scanner.nextInt();
            System.out.println("Enter car features: ");
            String features = scanner.next();
            System.out.println("Enter car fuel level: ");
            double fuelLevel = scanner.nextDouble();
            System.out.println("Enter car rental rate per day: ");
            double rentalRate = scanner.nextDouble();
            String rentalStatus;
            do {
                System.out.println("Rented or Available? ");
                rentalStatus = scanner.next();
                if (rentalStatus.equalsIgnoreCase("rented")) {
                    rented = false;
                } else if (rentalStatus.equalsIgnoreCase("available")) {
                    rented = false;
                } else {
                    System.out.println("_________________________________");
                    System.out.println("Invalid answer. Please try again.");
                }
            } while (rented);

            Car car = new Car(vehicleID, make, model, color, yearOfMan, features, fuelLevel, rentalRate, rentalStatus);
            vehicles.add(car);
            System.out.println("\nVehicle added successfully!");

            do {
                System.out.println("Do you want to add another car?");
                String answer = scanner.next();
                if (answer.equalsIgnoreCase("yes") || answer.equalsIgnoreCase("y")) {
                    addCar();
                    break;
                } else if (answer.equalsIgnoreCase("no") || answer.equalsIgnoreCase("n")) {
                    more = false;
                    break;
                } else {
                    System.out.println("_________________________________");
                    System.out.println("Invalid answer. Please try again.");
                }
            } while (true);
        } while (more);
    }

    public static void editCar() {
//        int i = 1;
//        System.out.println("CARS LIST");
//        for (Vehicle v : vehicles) {
//            System.out.println(i + ") ");
//            v.displayInfo();
//            i++;
//        }
//        System.out.println("Which car do you want to edit?");
//        int carNo = scanner.nextInt();
//        carNo = carNo - 1;
//        Vehicle v = vehicles.get(carNo);
    }

    public static void removeCar() {
        boolean more = true;
        int i=1;
        System.out.println("CARS LIST");
        System.out.println("ID  " + "Make   " + "Model   " + "Color   " + "Year    " + "Features   " + "Fuel Level   " + "Rental Rate   " + "Rental Status   ");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
        for (Car v : vehicles) {
            System.out.println("Car "+i+": "+v.vehicleId + "    " + v.make + "       " + v.model + "       " + v.color + "    " + v.yearOfMan + "    " + v.features + "    " + v.fuelLevel + "     " + v.rentalRate + "    " + v.rentalStatus + "\n");
        i++;
        }
        System.out.println("Which car do you want to remove?");
        int carNo = scanner.nextInt();
        carNo = carNo - 1;
        vehicles.remove(carNo);
        System.out.println("\nVehicle removed successfully!");

        do {
            System.out.println("Do you want to remove another car?");
            String answer = scanner.next();
            if (answer.equalsIgnoreCase("Yes") || answer.equalsIgnoreCase("Y")) {
                removeCar();
                break;
            } else if (answer.equalsIgnoreCase("No") || answer.equalsIgnoreCase("N")) {
                more = false;
                break;
            } else {
                System.out.println("_________________________________");
                System.out.println("Invalid answer. Please try again.");
            }
        } while (true);
    }

    public static void afterLogin() {
        System.out.println("1) Add new car\n2) Update car information\n3) Remove car\n4) Exit\nChoose option: ");
        int option = scanner.nextInt();
        switch (option) {
            case 1:
                addCar();
                afterLogin();
                break;
            case 2:
                editCar();
                afterLogin();
                break;
            case 3:
                removeCar();
                afterLogin();
                break;
            case 4:
                Files.Write("C:/Users/aseel/IdeaProjects/Main/car.txt");
                System.out.println("Exiting program. User data saved.");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    public static void loginUser() {
        System.out.println("Enter your username:");
        String username = scanner.nextLine();
        System.out.println("Enter your password:");
        String password = scanner.nextLine();
        if (username.equalsIgnoreCase("admin") && password.equalsIgnoreCase("admin")) {
            System.out.println("__________________________");
            System.out.println("Login successful. Welcome!\n");
            afterLogin();
        } else {
            System.out.println("Username or password is incorrect. Please try again.");
            loginUser();
        }
    }
}
