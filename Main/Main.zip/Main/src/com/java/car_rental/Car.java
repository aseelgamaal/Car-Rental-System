package com.java.car_rental;

import java.util.List;

public class Car extends Vehicle {
    public String pickup_location;
    public String date;
    public String time;
    public String return_location;

    public Car(){

    }
    public Car(int vehicleId, String make, String model, String color, int yearOfMan,
               String features, double fuelLevel, Double rentalRate,
               String rentalStatus){
        super(vehicleId, make, model, color, yearOfMan, features, fuelLevel, rentalRate, rentalStatus);
    }
    public Car(int vehicleId, String make, String model, String color, int yearOfMan,
               String features, double fuelLevel, Double rentalRate,
               String rentalStatus, String location, String date, String time, String return_location) {
        super(vehicleId, make, model, color, yearOfMan, features, fuelLevel, rentalRate, rentalStatus);
        this.pickup_location = location;
        this.date = date;
        this.time = time;
        this.return_location = return_location;
    }

    public String displayInfo() {
        return vehicleId + "," + make + "," + model + "," + color + "," + yearOfMan + "," + features + "," + fuelLevel + "," + rentalRate + "," + rentalStatus + "\n";
    }
    public void displayReservationInfo(){
        super.displayInfo();
        System.out.println("Pickup location   " + "Date   " + "Time   " + "Return location   ");
        System.out.println(pickup_location + "   " + date + "   " + time + "    " + return_location + "  ");
    }

}
