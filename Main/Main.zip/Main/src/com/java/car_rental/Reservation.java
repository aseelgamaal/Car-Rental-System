package com.java.car_rental;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
public class Reservation {
    private static int reservationIdCounter=1;
    public int reservationId;
    int customerId;
    int carId ; //hsaweha b id bta3 el car lma customer y3ml book
    Car reservedCar;
    String pickupDate;
    String returnDate;
    long duration;
    float totalPrice;
    String pickupLocation;
    String returnLocation;
    String Status; //(pending,confirmed,cancelled)

    public Reservation(int customerId ,String pickupDate,String returnDate,  String pickupLocation, String returnLocation,String status){
        this.reservationId = reservationIdCounter++;
        this.customerId=customerId;
        this.pickupDate=pickupDate;
        this.returnDate=returnDate;
        this.pickupLocation=pickupLocation;
        this.returnLocation=returnLocation;
        this.Status=status;
    }

    public static int getReservationIdCounter() {
        return reservationIdCounter;
    }

    public void setTotalPrice(float totalPrice) {
        this.totalPrice = totalPrice;
    } //5letha kda 34an h set feha total price lma a7sbo b2a


    //     function to return duration
    public long getDuration(String pickupDate, String returnDate ) { //reservationHistory.pickupDate and returnDate ely customer hyd5lhum
        String pattern = "yyyy-MM-dd";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        // Parse strings to LocalDate objects
        LocalDate startDate = LocalDate.parse(pickupDate, formatter);
        LocalDate endDate = LocalDate.parse(returnDate, formatter);
        duration=ChronoUnit.DAYS.between(startDate, endDate);
        return duration; //I will return it in a duration variable of datatype long
    }  //I will access this method in calculate total price by reservationHistory  field in customer class
    public void viewReservation(){
        System.out.println("Reservation ID: " + reservationId );
        System.out.println("Pickup Date: " + pickupDate );
        System.out.println("Return Date: " + returnDate );
        System.out.println("Pickup Location: " + pickupLocation );
        System.out.println("Return Location: " + returnLocation );
        System.out.println("Total Price " + totalPrice );
    }
//    public void modifyReservation(){
//        System.out.println("a.Pickup Date");
//        System.out.println("b.return Date");
//        System.out.println("c.Pickup Location");
//        System.out.println("a.Return Date");
//        System.out.println("a.Pickup Date");
//        System.out.println("Enter what you want to modify about your reservation:")
//    }
}
