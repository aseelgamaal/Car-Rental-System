package com.java.car_rental;
import java.util.ArrayList;
import java.util.List;

public class CarAgency {
    private int agencyId;
    private String locationAddress;
    private String locationCity;
    private String contactEmail;
    private String contactPhone;
    public static List<Car> availableCars;
    public double totalRevenu;
    //    ArrayList<Reservation> reservationHistory = new ArrayList<>(); //we want to add reservationHistory to it
    public CarAgency(int agencyId,String locationAddress,String locationCity,String contactEmail,String contactPhone){
        this.agencyId=agencyId;
        this.locationAddress=locationAddress;
        this.locationCity=locationCity;
        this.contactEmail=contactEmail;
        this.contactPhone=contactPhone;
        this.availableCars= new ArrayList<>(50);
        this.totalRevenu=0.0;
    }
    public void calcRevenue(){
        //3la hasb el price
    }
}
